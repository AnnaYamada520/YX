#!/system/bin/sh

print_line() {
    ui_print "$1"
    sleep 0.3
}

print_line "********************************************"
print_line " "
print_line "- 正在刷入模块..."
print_line "- 刷入后打开游戏自动开启美化"
print_line " "
print_line "- 释放模块文件"
sleep 0.5
print_line "- 设置脚本权限"
sleep 0.5
print_line "- 配置开机监控服务"
print_line " "
sleep 0.5
print_line "********************************************"
print_line "- 刷入完成！"
print_line "- 请重启手机后生效"
print_line "********************************************"

# 设置脚本权限
[ -f "$MODPATH/service.sh" ] && set_perm $MODPATH/service.sh 0 0 0755
[ -f "$MODPATH/scripts/an.sh" ] && set_perm $MODPATH/scripts/an.sh 0 0 0755