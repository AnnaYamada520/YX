#!/system/bin/sh

MODDIR=${0%/*}
TARGET_SCRIPT="$MODDIR/scripts/an.sh"
LOG_FILE="$MODDIR/monitor.log"
OBB_DIR="/storage/emulated/0/Android/obb"
CONFIG_FILE="$OBB_DIR/山田杏奈自动美化配置.h"
STATE_DIR="/data/local/tmp/zm_stxn_state"

log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

read_cfg() {
    grep "^$1=" "$CONFIG_FILE" 2>/dev/null | head -n1 | sed 's/^[^=]*=//' | tr -d ' \r\t'
}

create_default_config() {
    mkdir -p "$OBB_DIR" 2>/dev/null
    cat > "$CONFIG_FILE" << 'EOF'
// 0关闭 1开启
总开关=1
国际服=1
台湾服=1
日韩服=1
越南服=1
EOF
    chmod 0666 "$CONFIG_FILE" 2>/dev/null
}

log_msg "service.sh 启动"

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done
log_msg "系统启动完成"

if [ ! -f "$CONFIG_FILE" ]; then
    create_default_config
    log_msg "已生成默认配置: $CONFIG_FILE"
fi

mkdir -p "$STATE_DIR"
chmod 777 "$TARGET_SCRIPT" 2>/dev/null

log_msg "进入监控循环"

while true; do
    if [ ! -f "$CONFIG_FILE" ]; then
        create_default_config
        log_msg "配置丢失，已重建默认配置"
    fi

    total=$(read_cfg "总开关")
    intl=$(read_cfg "国际服")
    tw=$(read_cfg "台湾服")
    kr=$(read_cfg "日韩服")
    vn=$(read_cfg "越南服")

    pkgs=""
    if [ "$total" = "1" ]; then
        [ "$intl" = "1" ] && pkgs="$pkgs com.tencent.ig"
        [ "$tw"   = "1" ] && pkgs="$pkgs com.rekoo.pubgm"
        [ "$kr"   = "1" ] && pkgs="$pkgs com.pubg.krmobile"
        [ "$vn"   = "1" ] && pkgs="$pkgs com.vng.pubgmobile"
    fi

    for pkg in $pkgs; do
        if pidof "$pkg" > /dev/null 2>&1; then
            running=1
        else
            running=0
        fi

        last=$(cat "$STATE_DIR/$pkg" 2>/dev/null)
        [ -z "$last" ] && last=0

        if [ "$running" = "1" ] && [ "$last" = "0" ]; then
            log_msg "检测到 $pkg，执行美化"
            if [ -x "$TARGET_SCRIPT" ]; then
                "$TARGET_SCRIPT" >> "$LOG_FILE" 2>&1 &
            else
                log_msg "错误: $TARGET_SCRIPT 不可执行"
            fi
        fi

        echo "$running" > "$STATE_DIR/$pkg"
    done
    sleep 5
done